prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38424573699715147902
,p_default_application_id=>193328
,p_default_id_offset=>0
,p_default_owner=>'WKSP_ESPEFICICOSIFOFOSIS'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'KUTIMO'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let ele = document.getElementById("P1_NEW_DISPLAY");',
'',
'//Create the div',
'let div = document.createElement("div");',
'div.className = "progress-bar";',
'',
'',
'//Its child (hidden)',
'let prog = document.createElement("progress");',
'prog.value = ele.textContent;',
'prog.style.cssText = `',
'visibility:hidden;',
'height:0;',
'width:0;',
'`',
'prog.min = 0;',
'prog.max = 100;',
'//Set div style',
'',
'div.style.cssText = `',
'    ',
'    width: 25vw;',
'    height: 25vw;',
'    border-radius: 50%;',
'    background:',
'        radial-gradient(closest-side, #FFF4D9 60%, transparent 60% 100%),',
'        conic-gradient(#02C39A ${prog.value}%, #028090 0);',
'    transform(-40%,0%);',
'`;',
'',
'div.appendChild(prog)',
'',
'ele.replaceWith(div);',
'',
'// Complete button',
'const buttons = document.querySelectorAll(''.complete-button'');',
'',
'        // Define the function to be executed on click',
'        function handleClick(event) {',
'            let parent = event.target.parentElement.parentElement.parentElement.parentElement;',
'            ',
'',
'            let title = parent.querySelector(".a-CardView-title").textContent;',
'            let subtitle = parent.querySelector(".a-CardView-subTitle").textContent;',
'            ',
'            parent.remove();',
'            // Example using fetch API',
'            fetch(`https://apex.oracle.com/pls/apex/espeficicosifofosis/schem/complete/${title}/${subtitle}`, {',
'                method: ''GET'', // or ''POST'' if you need to send data',
'                })',
'                .then(response => response.json())',
'                .then(data => {',
'                console.log(''Success:'', data);',
'            })',
'            .catch(error => {',
'                console.error(''Error:'', error);',
'            });',
'            console.log(`\n\n\n\n ${title} ${subtitle} removed! \n\n\n\n`);',
'',
'            ',
'        }',
'',
'        // Loop through each element and add the event listener',
'        buttons.forEach(element => {',
'            element.addEventListener(''click'', handleClick);',
'        });',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'@import url(''https://fonts.googleapis.com/css2?family=Sen:wght@400..800&display=swap'');',
'',
'.a-CardView-header {',
'    background-color: #00A896; /* Card background color */',
'    border-radius: 10px; /* Rounded corners */',
'    outline-color: #00A896;',
'    box-shadow: 0 2px 4px rgba(0,0,0,0.1); /* Shadow for a subtle 3D effect */',
'    padding: 16px; /* Padding inside the card */',
'    color: #FFF4D9;',
'}',
'',
'.a-CardView {',
'    border-radius: 10px;',
'    /* background-color: #02C39A; */',
'}',
'',
'.a-CardView-subTitle {',
'    color: #fff4d9; /* Text color */',
'    font-style: italic; /* Italicize the text */',
'}',
'',
'.complete-button {',
'    color: #FFF4D9;',
'    background-color: #028090;',
'    border-color: 0px;',
'    border-radius: 8px;',
'    font-family: "Sen", sans-serif;',
'    align-items: center;',
'    font-size: 80%;',
'}',
'',
'.t-Form-inputContainer',
'{',
'    display: grid;',
'    place-items: center;',
'    justify-content: center;',
'}',
'',
'.fechi',
'{',
'    color: #05668D;',
'    text-align: center;',
'    font-family: "Sen", sans-serif;',
'    font-size: 500%;',
'    transform: translate(0%,20%);',
'}',
'',
'/* Base button styles */',
'.t-Button-label {',
'    background-color: #028090; /* Green background */',
'    color: #FFF4D9; /* White text */',
'    border: none; /* Remove border */',
'    padding: 15px 32px; /* Padding */',
'    text-align: center; /* Centered text */',
'    text-decoration: none; /* No underline */',
'    display: inline-block; /* Inline-block display */',
'    font-size: 16px; /* Font size */',
'    margin: 4px 2px; /* Margin */',
'    cursor: pointer; /* Pointer cursor on hover */',
'    border-radius: 4px; /* Rounded corners */',
'}',
'',
'/* Hover effect */',
'.button:hover {',
'    background-color: #45a049; /* Darker green on hover */',
'}',
'',
'',
'/*',
'.col-end',
'{',
'    position: absolute;',
'    top: 20%;',
'    left: 50%;',
'    transform: translate(75%, 0%);',
'    width: 20vw;',
'    height: 40vh;',
'    background-color: lightgreen;',
'}',
'*/',
'',
'/*',
'.t-Body-side',
'{',
'    background-color: #028090;',
'    width: 100%;',
'    padding: 20px;',
'};',
'.t_PageBody',
'{',
'    background-repeat: no-repeat;',
'    background-color: #fbefdc;',
'};',
'.t-Body-side',
'{',
'    background-color: #fbefdc;',
'}',
'.t-Body-main',
'{',
'    background-color: #fbefdc;',
'}',
'',
'.butcol1',
'{',
'    background-color: #00A896;',
'}',
'.butcol2',
'{',
'    background-color: #02C39A;',
'}',
'*/',
'/*',
'.a-ListView-item',
'{',
'    background-color: #00A896;',
'    color: #FFF4D9;',
'    margin: 1vw;',
'    width: 50%;',
'    height: 5vw;',
'    font-weight: light;',
'    font-family: "Sen", sans-serif;',
'    align-items: center;',
'    font-size: 120%;',
'    border-radius: 10%;',
'    overflow: clip;',
'    ',
'    ',
'}',
'',
'.a-ListView',
'{',
'    align-items: center;',
'    display: flex;',
'    border-radius:10%;',
'}',
'',
'li',
'{',
'    display: flex;',
'    justify-content: center;',
'    overflow: visible;',
'}',
'',
'ul {',
'    padding: 0;',
'    margin: 0;',
'}',
'*/'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(38702436859399161513)
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38445094122188586630)
,p_plug_name=>'Hoy'
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source=>'<p class="fechi">Today</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38445094213462586631)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--stretch:t-ImageRegion--auto:t-ImageRegion--scale-down:t-ImageRegion--square:t-ImageRegion--noFilter:t-Form--large'
,p_plug_template=>wwv_flow_imp.id(38702215084032161327)
,p_plug_display_sequence=>80
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_location=>null
,p_region_image=>'https://apex.oracle.com/pls/apex/r/espeficicosifofosis/193328/files/static/v7/static/IMG_9006.PNG'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38821622831394257213)
,p_plug_name=>'Tasklist'
,p_region_name=>'habit_tile'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38701785244956161312)
,p_plug_display_sequence=>30
,p_query_type=>'TABLE'
,p_query_table=>'K_HABITS'
,p_include_rowid_column=>false
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(38821622965598257214)
,p_region_id=>wwv_flow_imp.id(38821622831394257213)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>false
,p_title_column_name=>'HABIT_NAME'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'CATEGORY_NAME'
,p_body_adv_formatting=>true
,p_body_html_expr=>'<button class="complete-button">Complete</button>'
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'INITIALS'
,p_icon_class_column_name=>'HABIT_NAME'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38705219723998304024)
,p_button_sequence=>40
,p_button_name=>'newHabit'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(38702318662222161378)
,p_button_image_alt=>'New Habit'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38705220511355304032)
,p_button_sequence=>50
,p_button_name=>'deleteHabit'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(38702318662222161378)
,p_button_image_alt=>'Delete Habit'
,p_button_redirect_url=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38821623516033257220)
,p_name=>'P1_NEW'
,p_item_sequence=>70
,p_prompt=>'New'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    CASE ',
'        WHEN K_HABITS.ASSIGNMENT_COUNT != 0 THEN (K_HABITS.COMPLETED_COUNT / K_HABITS.ASSIGNMENT_COUNT) * 100',
'        ELSE 0',
'    END AS PERCENTAGE_TODAY',
' from K_HABITS K_HABITS'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(38702315819417161377)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp.component_end;
end;
/
