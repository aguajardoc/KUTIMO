prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38424573699715147902
,p_default_application_id=>193328
,p_default_id_offset=>0
,p_default_owner=>'WKSP_ESPEFICICOSIFOFOSIS'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'YearCalendar'
,p_alias=>'YEARCALENDAR'
,p_step_title=>'YearCalendar'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Region-header {',
'    display: none;',
'}',
'',
'.fc-toolbar-chunk {',
'  display: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'08'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38821625091165257235)
,p_plug_name=>'YearCalJan'
,p_region_name=>'jancalend'
,p_region_template_options=>'#DEFAULT#:i-h480:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(38702244845452161341)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT HABIT_ID,',
'DATE_ASSIGNED_TO_BEGIN',
'FROM   K_ASSIGNED_HABITS',
'WHERE  EXTRACT(MONTH FROM DATE_ASSIGNED_TO_BEGIN) = 1',
'AND    EXTRACT(YEAR FROM DATE_ASSIGNED_TO_BEGIN) = :P7_YEAR',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_ajax_items_to_submit=>'P7_YEAR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_column', 'HABIT_ID',
  'event_sorting', 'AUTOMATIC',
  'maximum_events_day', '5',
  'multiple_line_event', 'Y',
  'show_time', 'N',
  'show_tooltip', 'Y',
  'show_weekend', 'Y',
  'start_date_column', 'DATE_ASSIGNED_TO_BEGIN')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38959658771261570901)
,p_plug_name=>'YearCalFeb'
,p_region_template_options=>'#DEFAULT#:i-h480:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(38702244845452161341)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT HABIT_ID,',
'DATE_ASSIGNED_TO_BEGIN',
'FROM   K_ASSIGNED_HABITS',
'WHERE  EXTRACT(MONTH FROM DATE_ASSIGNED_TO_BEGIN) = 2',
'AND    EXTRACT(YEAR FROM DATE_ASSIGNED_TO_BEGIN) = :P7_YEAR',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_ajax_items_to_submit=>'P7_YEAR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_column', 'HABIT_ID',
  'event_sorting', 'AUTOMATIC',
  'maximum_events_day', '5',
  'multiple_line_event', 'Y',
  'show_time', 'N',
  'show_tooltip', 'Y',
  'show_weekend', 'Y',
  'start_date_column', 'DATE_ASSIGNED_TO_BEGIN')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38959658804658570902)
,p_plug_name=>'YearCalMar'
,p_region_template_options=>'#DEFAULT#:i-h480:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(38702244845452161341)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT HABIT_ID,',
'DATE_ASSIGNED_TO_BEGIN',
'FROM   K_ASSIGNED_HABITS',
'WHERE  EXTRACT(MONTH FROM DATE_ASSIGNED_TO_BEGIN) = 3',
'AND    EXTRACT(YEAR FROM DATE_ASSIGNED_TO_BEGIN) = :P7_YEAR',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_ajax_items_to_submit=>'P7_YEAR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_column', 'HABIT_ID',
  'event_sorting', 'AUTOMATIC',
  'maximum_events_day', '5',
  'multiple_line_event', 'Y',
  'show_time', 'N',
  'show_tooltip', 'Y',
  'show_weekend', 'Y',
  'start_date_column', 'DATE_ASSIGNED_TO_BEGIN')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38959658999561570903)
,p_plug_name=>'YearCalAbr'
,p_region_template_options=>'#DEFAULT#:i-h480:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(38702244845452161341)
,p_plug_display_sequence=>60
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT HABIT_ID,',
'DATE_ASSIGNED_TO_BEGIN',
'FROM   K_ASSIGNED_HABITS',
'WHERE  EXTRACT(MONTH FROM DATE_ASSIGNED_TO_BEGIN) = 4',
'AND    EXTRACT(YEAR FROM DATE_ASSIGNED_TO_BEGIN) = :P7_YEAR',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_ajax_items_to_submit=>'P7_YEAR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_column', 'HABIT_ID',
  'event_sorting', 'AUTOMATIC',
  'maximum_events_day', '5',
  'multiple_line_event', 'Y',
  'show_time', 'N',
  'show_tooltip', 'Y',
  'show_weekend', 'Y',
  'start_date_column', 'DATE_ASSIGNED_TO_BEGIN')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38959659019174570904)
,p_plug_name=>'YearCalMay'
,p_region_template_options=>'#DEFAULT#:i-h480:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(38702244845452161341)
,p_plug_display_sequence=>70
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT HABIT_ID,',
'DATE_ASSIGNED_TO_BEGIN',
'FROM   K_ASSIGNED_HABITS',
'WHERE  EXTRACT(MONTH FROM DATE_ASSIGNED_TO_BEGIN) = 5',
'AND    EXTRACT(YEAR FROM DATE_ASSIGNED_TO_BEGIN) = :P7_YEAR',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_ajax_items_to_submit=>'P7_YEAR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_column', 'HABIT_ID',
  'event_sorting', 'AUTOMATIC',
  'maximum_events_day', '5',
  'multiple_line_event', 'Y',
  'show_time', 'N',
  'show_tooltip', 'Y',
  'show_weekend', 'Y',
  'start_date_column', 'DATE_ASSIGNED_TO_BEGIN')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38959659145891570905)
,p_plug_name=>'YearCalJun'
,p_region_template_options=>'#DEFAULT#:i-h480:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(38702244845452161341)
,p_plug_display_sequence=>80
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT HABIT_ID,',
'DATE_ASSIGNED_TO_BEGIN',
'FROM   K_ASSIGNED_HABITS',
'WHERE  EXTRACT(MONTH FROM DATE_ASSIGNED_TO_BEGIN) = 6',
'AND    EXTRACT(YEAR FROM DATE_ASSIGNED_TO_BEGIN) = :P7_YEAR',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_ajax_items_to_submit=>'P7_YEAR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_column', 'HABIT_ID',
  'event_sorting', 'AUTOMATIC',
  'maximum_events_day', '5',
  'multiple_line_event', 'Y',
  'show_time', 'N',
  'show_tooltip', 'Y',
  'show_weekend', 'Y',
  'start_date_column', 'DATE_ASSIGNED_TO_BEGIN')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38959659240391570906)
,p_plug_name=>'YearCalJul'
,p_region_template_options=>'#DEFAULT#:i-h480:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(38702244845452161341)
,p_plug_display_sequence=>90
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT HABIT_ID,',
'DATE_ASSIGNED_TO_BEGIN',
'FROM   K_ASSIGNED_HABITS',
'WHERE  EXTRACT(MONTH FROM DATE_ASSIGNED_TO_BEGIN) = 7',
'AND    EXTRACT(YEAR FROM DATE_ASSIGNED_TO_BEGIN) = :P7_YEAR',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_ajax_items_to_submit=>'P7_YEAR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_column', 'HABIT_ID',
  'event_sorting', 'AUTOMATIC',
  'maximum_events_day', '5',
  'multiple_line_event', 'Y',
  'show_time', 'N',
  'show_tooltip', 'Y',
  'show_weekend', 'Y',
  'start_date_column', 'DATE_ASSIGNED_TO_BEGIN')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38959659321484570907)
,p_plug_name=>'YearCalAgo'
,p_region_template_options=>'#DEFAULT#:i-h480:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(38702244845452161341)
,p_plug_display_sequence=>100
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT HABIT_ID,',
'DATE_ASSIGNED_TO_BEGIN',
'FROM   K_ASSIGNED_HABITS',
'WHERE  EXTRACT(MONTH FROM DATE_ASSIGNED_TO_BEGIN) = 8',
'AND    EXTRACT(YEAR FROM DATE_ASSIGNED_TO_BEGIN) = :P7_YEAR',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_ajax_items_to_submit=>'P7_YEAR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_column', 'HABIT_ID',
  'event_sorting', 'AUTOMATIC',
  'maximum_events_day', '5',
  'multiple_line_event', 'Y',
  'show_time', 'N',
  'show_tooltip', 'Y',
  'show_weekend', 'Y',
  'start_date_column', 'DATE_ASSIGNED_TO_BEGIN')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38959659433683570908)
,p_plug_name=>'YearCalSep'
,p_region_template_options=>'#DEFAULT#:i-h480:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(38702244845452161341)
,p_plug_display_sequence=>110
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT HABIT_ID,',
'DATE_ASSIGNED_TO_BEGIN',
'FROM   K_ASSIGNED_HABITS',
'WHERE  EXTRACT(MONTH FROM DATE_ASSIGNED_TO_BEGIN) = 9',
'AND    EXTRACT(YEAR FROM DATE_ASSIGNED_TO_BEGIN) = :P7_YEAR',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_ajax_items_to_submit=>'P7_YEAR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_column', 'HABIT_ID',
  'event_sorting', 'AUTOMATIC',
  'maximum_events_day', '5',
  'multiple_line_event', 'Y',
  'show_time', 'N',
  'show_tooltip', 'Y',
  'show_weekend', 'Y',
  'start_date_column', 'DATE_ASSIGNED_TO_BEGIN')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38959659599249570909)
,p_plug_name=>'YearCalOct'
,p_region_template_options=>'#DEFAULT#:i-h480:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(38702244845452161341)
,p_plug_display_sequence=>120
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT HABIT_ID,',
'DATE_ASSIGNED_TO_BEGIN',
'FROM   K_ASSIGNED_HABITS',
'WHERE  EXTRACT(MONTH FROM DATE_ASSIGNED_TO_BEGIN) = 10',
'AND    EXTRACT(YEAR FROM DATE_ASSIGNED_TO_BEGIN) = :P7_YEAR',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_ajax_items_to_submit=>'P7_YEAR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_column', 'HABIT_ID',
  'event_sorting', 'AUTOMATIC',
  'maximum_events_day', '5',
  'multiple_line_event', 'Y',
  'show_time', 'N',
  'show_tooltip', 'Y',
  'show_weekend', 'Y',
  'start_date_column', 'DATE_ASSIGNED_TO_BEGIN')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38959659633866570910)
,p_plug_name=>'YearCalNov'
,p_region_template_options=>'#DEFAULT#:i-h480:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(38702244845452161341)
,p_plug_display_sequence=>130
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT HABIT_ID,',
'DATE_ASSIGNED_TO_BEGIN',
'FROM   K_ASSIGNED_HABITS',
'WHERE  EXTRACT(MONTH FROM DATE_ASSIGNED_TO_BEGIN) = 11',
'AND    EXTRACT(YEAR FROM DATE_ASSIGNED_TO_BEGIN) = :P7_YEAR',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_ajax_items_to_submit=>'P7_YEAR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_column', 'HABIT_ID',
  'event_sorting', 'AUTOMATIC',
  'maximum_events_day', '5',
  'multiple_line_event', 'Y',
  'show_time', 'N',
  'show_tooltip', 'Y',
  'show_weekend', 'Y',
  'start_date_column', 'DATE_ASSIGNED_TO_BEGIN')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38959659797564570911)
,p_plug_name=>'YearCalDec'
,p_region_template_options=>'#DEFAULT#:i-h480:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(38702244845452161341)
,p_plug_display_sequence=>140
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT HABIT_ID,',
'DATE_ASSIGNED_TO_BEGIN',
'FROM   K_ASSIGNED_HABITS',
'WHERE  EXTRACT(MONTH FROM DATE_ASSIGNED_TO_BEGIN) = 12',
'AND    EXTRACT(YEAR FROM DATE_ASSIGNED_TO_BEGIN) = :P7_YEAR',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_ajax_items_to_submit=>'P7_YEAR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_column', 'HABIT_ID',
  'event_sorting', 'AUTOMATIC',
  'maximum_events_day', '5',
  'multiple_line_event', 'Y',
  'show_time', 'N',
  'show_tooltip', 'Y',
  'show_weekend', 'Y',
  'start_date_column', 'DATE_ASSIGNED_TO_BEGIN')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38821625978381257244)
,p_name=>'P7_YEAR'
,p_item_sequence=>20
,p_prompt=>'Year'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:2023;2023,2024;2024,2025;2025,2026;2026,2027;2027'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(38702316141193161377)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38821626444093257249)
,p_name=>'New_1'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_YEAR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38821626511488257250)
,p_event_id=>wwv_flow_imp.id(38821626444093257249)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(38821625091165257235)
);
wwv_flow_imp.component_end;
end;
/
