prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38424573699715147902
,p_default_application_id=>193328
,p_default_id_offset=>0
,p_default_owner=>'WKSP_ESPEFICICOSIFOFOSIS'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>'Calendar'
,p_alias=>'CALENDAR'
,p_step_title=>'Calendar'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/5.10.2/main.min.js"></script>'
,p_css_file_urls=>'<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/5.10.2/main.min.css">'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'08'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38809441341982132486)
,p_plug_name=>'Calendar'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(38702244845452161341)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT K_ASSIGNED_HABITS.HABIT_ID, ',
'       K_HABITS.HABIT_NAME, ',
'       K_ASSIGNED_HABITS.DATE_ASSIGNED_TO_BEGIN,',
'       K_ASSIGNED_HABITS.DATE_ASSIGNED_TO_END',
'FROM K_ASSIGNED_HABITS',
'JOIN K_HABITS ',
'ON K_ASSIGNED_HABITS.HABIT_ID = K_HABITS.HABIT_ID;',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'calendar_views_and_navigation', 'month:week:day:navigation',
  'display_column', 'HABIT_NAME',
  'drag_and_drop', 'N',
  'end_date_column', 'DATE_ASSIGNED_TO_END',
  'event_sorting', 'AUTOMATIC',
  'first_hour', '9',
  'maximum_events_day', '10',
  'multiple_line_event', 'Y',
  'primary_key_column', 'HABIT_ID',
  'show_time', 'Y',
  'show_tooltip', 'Y',
  'show_weekend', 'Y',
  'start_date_column', 'DATE_ASSIGNED_TO_BEGIN',
  'time_format', '00')).to_clob
);
wwv_flow_imp.component_end;
end;
/
