prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38424573699715147902
,p_default_application_id=>193328
,p_default_id_offset=>0
,p_default_owner=>'WKSP_ESPEFICICOSIFOFOSIS'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Graphs'
,p_alias=>'GRAPHS'
,p_step_title=>'Graphs'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38704551402482964339)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(38701779581422161310)
,p_plug_display_sequence=>20
,p_query_type=>'TABLE'
,p_query_table=>'CUSTOMERS'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_plug_query_num_rows=>15
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'list_view_features', 'ADVANCED_FORMATTING',
  'text_formatting', wwv_flow_string.join(wwv_flow_t_varchar2(
    '<ul>',
    '        <li class="list-item">',
    '            <div class="icon">📈</div>',
    '            <div class="details">',
    '                <div class="title">Task 1</div>',
    '                <div class="description">Description for Task 1 goes here.</div>',
    '                <div class="progress-container">',
    '                    <div class="progress-bar" style="width: 70%;"></div>',
    '                </div>',
    '            </div>',
    '        </li>',
    '        <li class="list-item">',
    '            <div class="icon">🔧</div>',
    '            <div class="details">',
    '                <div class="title">Task 2</div>',
    '                <div class="description">Description for Task 2 goes here.</div>',
    '                <div class="progress-container">',
    '                    <div class="progress-bar" style="width: 40%;"></div>',
    '                </div>',
    '            </div>',
    '        </li>',
    '        <li class="list-item">',
    '            <div class="icon">📝</div>',
    '            <div class="details">',
    '                <div class="title">Task 3</div>',
    '                <div class="description">Description for Task 3 goes here.</div>',
    '                <div class="progress-container">',
    '                    <div class="progress-bar" style="width: 90%;"></div>',
    '                </div>',
    '            </div>',
    '        </li>',
    '    </ul>')))).to_clob
);
wwv_flow_imp.component_end;
end;
/
